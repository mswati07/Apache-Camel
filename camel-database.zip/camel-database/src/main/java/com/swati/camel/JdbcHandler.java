package com.swati.camel;

import java.util.List;

public class JdbcHandler{
	public void display(List l) {
		for(int i=0 ; i<l.size(); i++) {
			System.out.println(l.get(i));
		}
	}

}
