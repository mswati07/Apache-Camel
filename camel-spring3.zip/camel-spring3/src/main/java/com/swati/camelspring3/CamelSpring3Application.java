package com.swati.camelspring3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelSpring3Application {

	public static void main(String[] args) {
		SpringApplication.run(CamelSpring3Application.class, args);
	}

}
