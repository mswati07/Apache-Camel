package com.swati.camelspring3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelSpring3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
